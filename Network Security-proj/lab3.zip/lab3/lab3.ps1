# Ange sökvägen till signaturfilen och mappen med filer att kontrollera
$signatureFile = "C:\Users\safiy\lab3\siglist.txt"
$targetDirectory = "C:\Users\safiy\Downloads\ps\ps"

# Läs in signaturerna från siglist.txt
$sigList = @{}
Get-Content $signatureFile | ForEach-Object {
    $parts = $_ -split ";"
    if ($parts.Length -ge 2) {
        $fileType = $parts[0]
        $header = $parts[1]
        $footer = if ($parts.Length -eq 3) { $parts[2] } else { $null }
        $sigList[$fileType] = @{Header = $header; Footer = $footer}
    }
}

# Funktion för att konvertera byte-array till hex-sträng
function Convert-ToHexString {
    param ([byte[]]$bytes)
    ($bytes | ForEach-Object { $_.ToString("X2") }) -join ""
}

# Funktion för att läsa filens signatur (huvud + ev. sidfot)
function Get-FileSignature {
    param ([string]$filePath, [int]$headerLength = 8, [int]$footerLength = 8)

    $bytes = [System.IO.File]::ReadAllBytes($filePath)
    $headerHex = Convert-ToHexString -bytes $bytes[0..($headerLength-1)]
    $footerHex = if ($bytes.Length -ge $footerLength) {
        Convert-ToHexString -bytes $bytes[($bytes.Length-$footerLength)..($bytes.Length-1)]
    } else {
        $null
    }

    return @{Header = $headerHex; Footer = $footerHex}
}

# Funktion för att kontrollera filsignaturer
function Check-FileSignatures {
    param ([string]$directory)

    Get-ChildItem -Path $directory -File | ForEach-Object {
        $filePath = $_.FullName
        $fileName = $_.Name
        $extension = $_.Extension.TrimStart(".").ToUpper()

        # Läs in filens header och footer
        $fileSig = Get-FileSignature -filePath $filePath

        # Identifiera filtyp baserat på signatur
        $matchedType = $null
        foreach ($type in $sigList.Keys) {
            $expectedHeader = $sigList[$type]["Header"]
            $expectedFooter = $sigList[$type]["Footer"]

            if ($expectedHeader -and ($fileSig["Header"] -match "^$expectedHeader.*")) {
                if (-not $expectedFooter -or $fileSig["Footer"] -match "$expectedFooter$") {
                    $matchedType = $type
                    break
                }
            }
        }

        # Hantering av ZIP-baserade format (DOCX, XLSX, PPTX)
        if ($matchedType -eq "ZIP" -and $extension -in @("DOCX", "XLSX", "PPTX")) {
            $matchedType = $extension
        }

        # Hantering av textfiler (de saknar signatur)
        if ($extension -eq "TXT" -and -not $matchedType) {
            $matchedType = "TXT"
        }

        # Visa resultat
        if ($matchedType) {
            $status = if ($matchedType -eq $extension) { "OK" } else { "FELMATCH" }
            Write-Output "$fileName : Förväntad ($extension) -> Faktisk ($matchedType) : Status = $status"
        } else {
            Write-Output "$fileName : Okänd filtyp"
        }
    }
}

# Kör kontrollen på mappen
Check-FileSignatures -directory $targetDirectory